#include "ky_control.h"
#include <stdio.h>
#include <termio.h>
using namespace std;
void communication::Callback(const std_msgs::Int32::ConstPtr& msg){
	cout << "get message "<<msg->data<<endl;
	if(msg->data == 1){
		if(!is_offboard){
			cout << "Under the Offboard Mode." << endl;
			is_offboard=true;
		}
	}
	else if(msg->data == 0){
		if(is_offboard){
			cout << "Exit the Offboard Mode." << endl;
			is_offboard=false;
		}
	}
}

int scanKeyboard()
{
	int in;
	struct termios new_settings;
	struct termios stored_settings;
	tcgetattr(0,&stored_settings);
	new_settings = stored_settings;
	new_settings.c_lflag &= (~ICANON);
	new_settings.c_cc[VTIME] = 0;
	tcgetattr(0,&stored_settings);
	new_settings.c_cc[VMIN] = 1;
	tcsetattr(0,TCSANOW,&new_settings);
 
	in = getchar();
 
	tcsetattr(0,TCSANOW,&stored_settings);
	return in;
}

void communication::run(){
	std_msgs::Int32 _msg;
	//ros::Rate loop_rate(10);
	cout<<"in to run"<<endl;
	while(true){
		ros::spinOnce();
		//if(is_offboard){
			cout<<"in to run"<<endl;
			switch(scanKeyboard()){
				case 119:

					_msg.data=0;
					keyboard_control_pub.publish(_msg);
					cout << "forward" <<endl;
					break;
				case 115:
					cout << "backward" <<endl;
					_msg.data=1;
					keyboard_control_pub.publish(_msg);
					break;
				case 97:
					cout << "left" <<endl;
					_msg.data=2;
					keyboard_control_pub.publish(_msg);
					break;
				case 100:
					cout << "right" <<endl;
					_msg.data=3;
					keyboard_control_pub.publish(_msg);
					break;
				case 101:
					cout << "up" <<endl;
					_msg.data=4;
					keyboard_control_pub.publish(_msg);
					break;
				case 114:
					cout << "down" <<endl;
					_msg.data=5;
					keyboard_control_pub.publish(_msg);
					break;
				case 111:
					cout << "anticlockwise" <<endl;
					_msg.data=6;
					keyboard_control_pub.publish(_msg);
					break;
				case 112:
					cout << "clockwise" <<endl;
					_msg.data=7;
					keyboard_control_pub.publish(_msg);
					break;
			}
		
	//	}
	//	loop_rate.sleep();
	}
}



